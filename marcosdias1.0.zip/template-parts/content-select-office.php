<section class="select_office">

    <div class="container select_office_list">
        <h4 class="title-default">Selecione um dos estados onde estamos presentes</h4>
        <select name="" id="select_offices">
            <option value="none" id="firstOptionOffice">Selcione o Estado</option>
            <option value="MG">Minas Gerais</option>
            <option value="SP">São Paulo</option>
            <option value="RJ">Rio de Janeiro</option>
            <option value="ES">Espírito Santo</option>
            <option value="BA">Bahia</option>
            <option value="PE">Pernambuco</option>
            <option value="PR">Paraná</option>
            <option value="SC">Santa Catarina</option>
            <option value="RS">Rio Grande do Sul</option>
            <option value="DF">Distrito Federal</option>
            <option value="GO">Goiás</option>
            <option value="MT">Mato Grosso</option>
            <option value="MS">Mato Grosso do Sul</option>
        </select>
    </div>

</section>