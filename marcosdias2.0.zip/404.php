<?php get_header() ?>
    
    <main>

        <section class="container error_page">

            <h2 class="title-default">404</h2>
            <h2 class="subtitle-default">Página solicitada não encontrada</h2>

        </section>

    </main>

<?php get_footer() ?>